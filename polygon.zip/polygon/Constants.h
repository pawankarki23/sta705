#ifndef CONSTANTS
#define CONSTANTS

const int      bh        =  30;       // button height
const int      bw        = 100;       // button width
const int      sp        =   5;       // a little space
const int      ww        = 600;       // window width
const int      wh        = 600;       // window height

#endif

