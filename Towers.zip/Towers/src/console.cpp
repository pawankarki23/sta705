#include <stdio.h>

struct Peg
  {
  int* stack;
  void push(int);
  int  pop();
  int  top;
  void print(int);
       Peg(int n);
  };
  
Peg::Peg(int n)
  {
  stack = new int[n];
  top   = 0;
  }  
  
void Peg::print(int id)
  {
  fprintf(stderr, "peg %d:", id);
  for(int i=0; i<top; i++) fprintf(stderr, "%5d", stack[i]);
  fprintf(stderr, "\n");
  }
  
void Peg::push(int disk)
  {
  stack[top++] = disk;
  }
  
int Peg::pop()
  {
  return stack[--top];
  }

Peg* peg[3];
    
void move_disk(int from, int dest)
  {
  printf("peg %d -> peg %d\n", from, dest);
  int k = peg[from]->pop();
  peg[dest]->push(k);
  }
  
void move_stack(int n, int from, int inter, int dest) 
  {
  if(n == 0) return;
  move_stack(n-1, from, dest, inter);
  move_disk(from, dest);
  move_stack(n-1, inter, from, dest);
  } 
    
int main()
  {
  const int n = 5;
  // create instances of three pegs
  for(int i=0; i<3; i++)
    peg[i] = new Peg(n);
  // put n disks on peg 0
  for(int i=0; i<n; i++)
    peg[0]->push(i);
  // show initial state  
  for(int i=0; i<3; i++)
    peg[i]->print(i);
  // move it  
  move_stack(n, 0, 1, 2);
  // show final state  
  for(int i=0; i<3; i++)
    peg[i]->print(i);
  return 0;
  }  

