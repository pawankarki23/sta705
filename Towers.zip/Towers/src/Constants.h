#ifndef CONSTANTS
#define CONSTANTS

const int      bh        =   30;       // base height
const int      iw        =   50;       // input field width
const int      ih        =   25;       // input field height
const int      sp        =    5;       // a little space
const int      ww        = 1000;       // window width
const int      wh        =  500;       // window height

#endif

