
dyn.load("Convolve.so")

lengths <- function(na, nb)
  {
  .C("setup", as.integer(length(a)),
                              as.integer(length(b)))
  sprintf("For vectors of length %d and %d.\n", na, nb)
  }

convolution <- function(a, b)
  {
  ab <- rep(0.0, length(a)+length(b)-1)
  r  <- .C("evaluate", as.numeric(a), as.numeric(b),
                                      as.numeric(ab))
  r[[3]]
  }

a <- rep(1,6)/6.0
b <- a

lengths(length(a), length(b))
ab <- convolution(a, b)

print(a)
print(b)
dist <- data.frame(values = 2:12, probs = ab)
print(dist)

