#ifndef GSLLINEAR
#define GSLLINEAR

#include <gsl/gsl_errno.h>
#include <gsl/gsl_odeiv2.h>

class Table;

struct DEmodel
  {
  int      n;
  double*  infusion;
  double*  initial;
  double** p;
  double*  q;
  void     load(double*, double*, double*);
           DEmodel(int);
  };

int function(double t, const double y[], double f[], void *data);
int jacobian(double t, const double y[], double *dfdy, double dfdt[], 
                                                         void *data);

class GSLlinear
  {
  double  hstart;
  double  epsabs;
  double  epsrel;
  public:
  void    set_hstart(double);
  void    set_epsabs(double);
  void    set_epsrel(double);
  int     solve(DEmodel* A, double* time, Table* Y);
          GSLlinear();
         ~GSLlinear();
  };
#endif

