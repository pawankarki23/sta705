#ifndef COMPMODEL
#define COMPMODEL

#include <stdio.h>

class DEmodel;

class CompModel
  {
  double*       param;                 // points beginning of parameters
  public:
  int           n;                     // number of compartments
  int*          from;                  // vector of source compartments
  int*          to;                    // vector of destination compartments
  int           inf;                   // id of infusion compartment
  int           bol;                   // id of bolus compartment
  int           nr;                    // number of rate constants
  int           np;                    // number of parameters
  double*       system(double* theta); // loads parameters into system
  DEmodel*      S;
  void          bolus_site(int);
  void          infusion_site(int);
  void          print(FILE*, const char*);
                CompModel(int nr, int* from, int* to);
                ~CompModel();
  };
  
#endif
